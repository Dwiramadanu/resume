# resume
Contoh html untuk membuat biodata dengan gambar dan icon, hanya dengan tabel
